define(
"dojo/cldr/nls/en-ca/currency", //begin v1.x content
{
	"CAD_symbol": "$",
	"USD_symbol": "US$"
}
//end v1.x content
);